import { put, takeLatest } from "redux-saga/effects";
import axios from "axios";

import * as actions from "../actions/actionTypes";
import API_URL from "../../config/apiConfig";

const config = {
  headers: {
    "Content-Type": "application/json"
  }
};

function* fetchAqlGroupRule() {
  const data = {
    userName: "kaurr31",
    userRole: "dtappadmin",
    plantCode: "RMT"
  };
  console.log(data);
  try {
    /*const limitConfigs = yield axios.post(
      API_URL.getLimitRules.url,
      data,
      config
    );*/

    const aqlConfigs = [
      {
        productId: "147",
        productName: "teteet",
        roleCode: "dtappadmin",
        planCode: "RMT",
        prePopulated: false,
        active: false
      },
      {
        productId: "148",
        productName: "asd",
        roleCode: "dtappadmin",
        planCode: "RMT",
        prePopulated: false,
        active: false
      },
      {
        productId: "165",
        productName: "TEST_ab",
        roleCode: "dtappadmin",
        planCode: "RMT",
        prePopulated: false,
        active: false
      }
    ];

    yield put({
      type: actions.FETCH_AQL_GROUP_SUCCESS,
      payload: aqlConfigs
    });
  } catch (error) {
    yield put({ type: actions.FETCH_AQL_GROUP_FAILED, error });
  }
}

function* updateAqlGroupNames(action) {
  let reqPayload = null;
  console.log(action);
  if (action.payload.deleteItems != null) {
    action.payload.deleteItems.forEach(
      item =>
        (reqPayload = {
          userName: "kaurr31",
          userRole: "dtappadmin",
          productName: item.productName,
          userComments: "Testing",
          typeOfConfimation: "User Confirmation",
          meaningCapture: "Confirmation of Defect Category to Defect Type",
          apiUrl: API_URL.deleteAqlGroup.url
        })
    );
  }

  if (action.payload.newItems != null) {
    action.payload.newItems.forEach(
      item =>
        (reqPayload = {
          userName: "kaurr31",
          userRole: "dtappadmin",
          userComment: action.payload.fields.comments,
          productName: item.productName,
          typeOfConfimation: "User Confirmation",
          apiUrl: API_URL.addAqlGroup.url
        })
    );
  }

  const userDetails = {
    userName: "kaurr31",
    password: action.payload.fields.password
  };

  try {
    const auth = yield axios.post(
      API_URL.authentication.url,
      userDetails,
      config
    );
    if (!auth.data.Authentication) {
      yield put({
        type: actions.AUTHENTICATION_SUCCESS,
        payload: auth.data
      });
    }

    if (auth.data.success) {
      try {
        const data = yield axios.post(reqPayload.apiUrl, reqPayload, config);

        yield put({ type: actions.UPDATE_AQL_GROUP_SUCCESS });
        yield put({
          type: actions.FETCH_AQL_GROUP_REQUESTED
        });
      } catch (error) {
        yield put({ type: actions.FETCH_AQL_GROUP_FAILED, error });
      }
    }
  } catch (error) {
    yield put({ type: actions.AUTHENTICATION_FAILED, error });
  }
}

function* validateAqlGroupNames(action) {
  const payload = {
    userName: "kaurr31",
    userRole: "dtappadmin",
    productName: action.payload.productName,
    plantCode: "RMT"
  };

  try {
    const response = yield axios.post(
      API_URL.checkDuplicate.url,
      payload,
      config
    );

    yield put({
      type: actions.VALIDATE_AQL_GROUP_NAMES_SUCCESS,
      payload: response.data
    });
  } catch (error) {
    yield put({ type: actions.VALIDATE_AQL_GROUP_NAMES_FAILED, error });
  }
}

function* fetchDefectAQLRules() {
  const data = {
    productId: "147"
  };

  try {
    // const limitConfigs = yield axios.post(
    //   API_URL.defectLimitRules.url,
    //   data,
    //   config
    // );

    const aqlConfigs = [
      {
        productId: 147,
        createdBy: "POLAS03",
        createdAt: "2020-02-18 08:43:27.82",
        modifiedBy: "POLAS03",
        modifiedDat: "2020-02-18 08:43:27.82",
        active: true,
        defCatId: "8",
        defCatName: "Minor",
        limitRuleId: "442",
        label2SelectedValue: ">=",
        label2TextValue: "999.000",
        percentageValueFlag: false,
        isNew: false,
        edited: false,
        totalDefect: false,
        checkBoxVisibility: true,
        sort: false,
        label2TextStatus: "visualInspectionNumericTextBoxNoError",
        optionLabel2: "Fail Condition",
        headerName: "",
        value: "%"
      },
      {
        productId: 147,
        value: "%",
        createdBy: "POLAS03",
        createdAt: "2020-02-18 08:43:27.82",
        modifiedBy: "POLAS03",
        modifiedDat: "2020-02-18 08:43:27.82",
        active: true,
        defCatId: "9",
        defCatName: "Major",
        limitRuleId: "443",
        label2SelectedValue: ">",
        label2TextValue: "45.000",
        percentageValueFlag: false,
        isNew: false,
        edited: false,
        totalDefect: false,
        checkBoxVisibility: true,
        sort: false,
        label2TextStatus: "visualInspectionNumericTextBoxNoError",
        headerName: "",
        optionLabel2: "Fail Condition"
      },
      {
        productId: 147,
        value: "%",
        createdBy: "POLAS03",
        createdAt: "2020-02-18 08:43:27.82",
        modifiedBy: "POLAS03",
        modifiedDat: "2020-02-18 08:43:27.82",
        active: true,
        defCatId: "10",
        defCatName: "Critical",
        limitRuleId: "444",
        label2SelectedValue: ">=",
        label2TextValue: "55.000",
        percentageValueFlag: false,
        isNew: false,
        edited: false,
        totalDefect: false,
        checkBoxVisibility: true,
        sort: false,
        label2TextStatus: "visualInspectionNumericTextBoxNoError",
        optionLabel2: "Fail Condition",
        headerName: ""
      },
      {
        productId: 147,
        value: "%",
        createdBy: "POLAS03",
        createdAt: "2020-02-18 08:43:27.82",
        modifiedBy: "POLAS03",
        modifiedDat: "2020-02-18 08:43:27.82",
        active: true,
        defCatId: "162",
        defCatName: "Total Defects",
        limitRuleId: "445",
        label2SelectedValue: ">=",
        label2TextValue: "0.000",
        percentageValueFlag: false,
        isNew: false,
        edited: false,
        totalDefect: false,
        checkBoxVisibility: false,
        sort: true,
        label2TextStatus: "visualInspectionNumericTextBoxNoError",
        headerName: "",
        optionLabel2: null
      }
    ];

    yield put({
      type: actions.FETCH_DEFECT_AQL_GROUP_RULE_SUCCESS,
      payload: aqlConfigs
    });
  } catch (error) {
    yield put({ type: actions.FETCH_AQL_GROUP_FAILED, error });
  }
}

export default function* aqlConfigSaga() {
  yield takeLatest(actions.FETCH_AQL_GROUP_REQUESTED, fetchAqlGroupRule);
  yield takeLatest(
    actions.FETCH_DEFECT_AQL_GROUP_RULE_REQUESTED,
    fetchDefectAqlRules
  );
  yield takeLatest(actions.UPDATE_AQL_GROUP_REQUESTED, updateAqlGroupNames);
  yield takeLatest(
    actions.VALIDATE_AQL_GROUP_NAMES_REQUESTED,
    validateAqlGroupNames
  );
}
