import React from "react";
import PropTypes from "prop-types";
import { H4, H6, Button, Icon } from "../../../../common/utils";
import Spinner from "../../../../common/spinner";
import TabAction from "../../tabActions";
import { AgGridReact } from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';

const AqlRule = props => (
    <>
    {!props.isloading ? (
        <section className="tab-section">
           <H4 className="tab-descr">Select and/or add Limit Group</H4>
           <Button onClick={props.openAdd} className="add-new">
          <Icon icon="add-icon" /> Add
        </Button>
        <div className="tab-content container-fluid">
        {props.aqlConfigs && props.aqlConfigs.length > 0 ? 
          <div className="row">
            <div
                className="list-item"
              > 
                <span className="item-content">
                    <select className="form-control" name="selectLimitGroup" onChange={e => props.changeHandler(e)}>
                       <option>Select</option>
                        { props.aqlConfigs.map((item) => <option key={item.productId} value={item.productId}>{item.productName}</option>)}
                    </select>
                </span>
                <span
                    className="item-remove">
                   < Button onClick={() => props.openDelete()} className="remove-new"
                  >
                  <Icon icon="close-icon" />Remove
                    </Button>
                  </span>
              </div>
              <div className="row">
              <div className="ag-theme-alpine-dark" style={ {height: '300px', width: '500px', padding: '10px'} }>
                <AgGridReact
                    columnDefs={props.columnDefs}
                    rowData={props.rowData}>
                </AgGridReact>
              </div>
              <div className="ag-theme-alpine-dark" style={ {height: '300px', width: '500px' ,padding: '10px'} }>
                <AgGridReact
                    columnDefs={props.columnDefs}
                    rowData={props.rowData}>
                </AgGridReact>
              </div>
                  </div>
                  </div>
                      
          : <H6 className="tab-descr mt-3 text-muted">No Limit Group available</H6>}  
          
        </div>
        <TabAction
          clickSave={props.openConfirm}
          clickCancel={props.clearHandler}
          disabled={props.disabled}
        />
      </section>
    ) : (
      <Spinner />
    )}
  </>
);

AqlRule.propTypes = {
    aqlConfigs: PropTypes.array,
    deletedIds: PropTypes.array,
    openAdd: PropTypes.func,
    openDelete: PropTypes.func
};

export default AqlRule;

