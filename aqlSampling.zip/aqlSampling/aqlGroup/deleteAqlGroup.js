import React from "react";
import PropTypes from 'prop-types';

import { Button, Icon, H3, H5 } from "../../../../common/utils";

const DeleteAqlGroup = props => {
  return (
    <div className="modal-contianer">
    {!props.confirmAction ? (
      <>
        <div className="modal-header">
          <H3>Confirm Removal of Limit Group?</H3>
          <span onClick={props.handleCloseModal}>
            <Icon icon="close-icon" />
          </span>
        </div>
        <div className="modal-content">
          <label>
            Are you sure you would like to remove the Limit Group{" "}
            <strong>{props.deletedItem.username}</strong>?{" "}
          </label>
        </div>
        <div className="modal-footer">
          <Button onClick={props.handleCloseModal} className="btn btn-cancel">
            <Icon icon="close-icon" /> Cancel
          </Button>
          <Button
            onClick={() =>
              props.deleteAqlGroup(props.deletedItem.id)
            }
            className="btn btn-save"
          >
            <Icon icon="save-icon" /> Delete Type
          </Button>
        </div>
      </>
    ) : (
      <div className="modal-header">
        <H5>Limit Group Type removed successfully</H5>
        <span onClick={props.handleCloseModal}>
          <Icon icon="close-icon" />
        </span>
      </div>
    )}
  </div>
  )
};

DeleteAqlGroup.propTypes = {
  deletedItem: PropTypes.object,
  deleteLimitGroup: PropTypes.func,
  confirmAction: PropTypes.bool,
  handleCloseModal: PropTypes.func
};

export default DeleteAqlGroup;
