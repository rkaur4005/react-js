import React from "react";
import PropTypes from 'prop-types';

import { Button, Icon, H3, H5, H6 } from "../../../../common/utils";
import SpinnerBar from '../../../../common/spinnerBar';

const AddAqlGroup = props => {
  return (
    <div className="modal-contianer">
      { !props.confirmAction ? 
      (<>
        <div className="modal-header">
          <H3>Add New Aql Group</H3>
          <span onClick={props.handleCloseModal}>
            <Icon icon="close-icon" />
          </span>
        </div>
        <div className="modal-content">
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              name="aqlGroup"
              value={props.fields.aqlGroup}
              onChange={e => props.changeHandler("aqlGroup", e)}
            />
          </div>
          {props.isLoading ? <SpinnerBar /> : (props.errors.aqlGroup && <H6 className="text-danger mb-0">{props.errors.aqlGroup}</H6>)}
        </div>
        <div className="modal-footer">
          <Button onClick={() => props.handleClearForm('add')} className="btn btn-cancel">
            <Icon icon="close-icon" /> Clear
          </Button>
          <Button onClick={props.addAqlGroup} className="btn btn-save">
            <Icon icon="add-icon" /> Save
          </Button>
        </div>
      </>)
      : 
      (<div className="modal-header">
        <H5>Lmit Group added successfully</H5>
        <span onClick={props.handleCloseModal}>
          <Icon icon="close-icon" />
        </span>
      </div>) }
    </div>
  );
};

AddAqlGroup.propTypes = {
  fields: PropTypes.object,
  changeHandler: PropTypes.func,
  errors: PropTypes.object,
  handleClearForm: PropTypes.func,
  addCategory: PropTypes.func,
  confirmAction: PropTypes.bool,
  handleCloseModal: PropTypes.func
};

export default AddAqlGroup;
