import * as actionTypes from "../../actions/actionTypes";

const defaultSate = {
  isError: false,
  isLoading: true,
  limitGroupData: [],
  defectLimitGroupRules: [],
  aqlGroupNames: null,
  isSaved: false,
  error: null,
  authDetails: null
};

const addAqlGroup = (state, action) => {
  state.aqlGroupData.push(action.payload);
  return { ...state };
};

const addDefectRulesData = (state, action) => {
  state.defectAqlGroupRules.push(action.payload);
  return { ...state };
};

const deleteAqlGroupData = (state, action) => {
  const filteredItems = state.aqlGroupData.filter(
    item => item.id !== action.payload.id
  );
  state.aqlGroupData = filteredItems;
  return { ...state };
};

const resetLimitGroups = (state, action) => {
  if (action.payload === "add") {
    state.aqlGroupNames = null;
  }
  if (action.payload === "auth") {
    state.authDetails = null;
  }
  if (Array.isArray(action.payload)) {
    action.payload.forEach(newItem => {
      state.aqlGroupData = state.aqlGroupData.filter(
        item => item.accLoseTypeId !== newItem.accLoseTypeId
      );
    });
  }
  return { ...state };
};

export default function(state = defaultSate, action) {
  /*const testData = [
      {
        "typeName": "male",
        "isActive": true,
        "value": "male",
      },
      {
        "typeName": "female",
        "isActive": true,
        "value": "male",
      },
      {
        "typeName": "noGender",
        "isActive": true,
        "value": "male",
      }
    ];*/
  switch (action.type) {
    case actionTypes.FETCH_AQL_GROUP_REQUESTED:
      return {
        ...state,
        isLoading: true,
        isSaved: false,
        aqlGroupNames: null
      };
    case actionTypes.FETCH_AQL_GROUP_SUCCESS:
      return {
        ...state,
        isLoading: false,
        aqlGroupData: action.payload
      };
      case actionTypes.FETCH_DEFECT_AQL_GROUP_RULE_REQUESTED:
      return {
        ...state,
        isLoading: true,
        isSaved: false,
        defectAqlGroupRules: null
      };
    case actionTypes.FETCH_DEFECT_AQL_GROUP_RULE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        defectLimitGroupRules: action.payload
      };
    case actionTypes.ADD_AQL_GROUP:
      return addAQLGroup(state, action);
      case actionTypes.ADD_AQL_DEFECT_GROUP:
        return addDefectRulesData(state, action);
    case actionTypes.DELETE_AQL_GROUP_DATA:
      return deleteAqlGroupData(state, action);
    case actionTypes.FETCH_AQL_GROUP_FAILED:
      return {
        ...state,
        isLoading: false,
        isError: true,
        error: action.error
      };
    case actionTypes.UPDATE_AQL_GROUP_REQUESTED:
      return {
        ...state,
        isLoading: true
      };
    case actionTypes.UPDATE_AQL_GROUP_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isSaved: true,
        authDetails: null
      };
    case actionTypes.UPDATE_AQL_GROUP_FAILED:
      return {
        ...state,
        isLoading: false,
        isError: true,
        error: action.error
      };
    case actionTypes.VALIDATE_AQL_GROUP_NAMES_REQUESTED:
      return {
        ...state,
        isLoading: true
      };
    case actionTypes.VALIDATE_AQL_GROUP_NAMES_SUCCESS:
      return {
        ...state,
        limitGroupNames: action.payload,
        isLoading: false,
        isError: false
      };
    case actionTypes.VALIDATE_AQL_GROUP_NAMES_FAILED:
      return {
        ...state,
        isLoading: false,
        isError: true,
        error: action.error
      };
    case actionTypes.AUTHENTICATION_REQUESTED:
      return {
        ...state,
        isLoading: true
      };
    case actionTypes.AUTHENTICATION_SUCCESS:
      return {
        ...state,
        authDetails: action.payload,
        isLoading: false
      };
    case actionTypes.AUTHENTICATION_FAILED:
      return {
        ...state,
        isLoading: false,
        isError: true,
        error: action.error
      };
    case actionTypes.FETCH_AQL_GROUP_RESET:
      return resetAqlGroups(state, action);
    default:
      return state;
  }
}
