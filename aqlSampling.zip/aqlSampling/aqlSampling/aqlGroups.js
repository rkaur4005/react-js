import React, { Component } from "react";
import { connect } from "react-redux";

import ModalContainer from "../../../common/modal";
import * as actions from "../../../store/actions";
import AqlRule from "../../../components/admin/aqlSampling/aqlGroup/addAqlGroup";
import AddAqlGroup from "../../../components/admin/aqlSampling/aqlGroup/deleteAqlGroup";
import DeleteAqlGroup from "../../../components/admin/aqlSampling/aqlGroup/aqlRule";
import UserConfirmation from "../../../components/admin/userConfirm";

class AqlGroup extends Component {
  constructor(props) {
    super(props);
    this.state = {
     
      confirmAction: false,
      showAddModal: false,
      showDeleteModal: false,
      showConfirmModal: false,
      deletedIds: [],
      selectedIds: [],
      newItems: null,
      deletedItem: null,
      deleteData: false,
      disabled: true,
      authDetails: null,
      selectLimitGroup: null,
      deletedLimitGroupName: null,
     
      fields: {
        comments: "",
        name: "",
        username: "",
        password: "",
        aqlGroup: ""
      },
      errors: {}
    };
  }

  static getDerivedStateFromProps(props, state) {
    let newItems = state.newItems;
    let authDetails = null;
    if (props.authDetails) {
      if (!props.authDetails.success) {
        authDetails = props.authDetails;
      }
    }
    if (props.isSaved) {
      newItems = null;
    }
    return { newItems, authDetails };
  }
  componentDidMount() {
    this.props.fetchAqlConfigs();
  }
  componentDidUpdate(prevProps) {
    if (prevProps.aqlGroupNames !== this.props.aqlGroupNames) {
      if (this.props.aqlGroupNames) {
        if (this.props.aqlGroupNames.status === "Failed") {
          this.addAqlGroupHandler();
        }
        if (
          this.props.aqlGroupNames.status ===
          "Record name existed earlier. Please enter a new name "
        ) {
          let errors = {};
          errors.aqlGroup =
            "Record name existed earlier. Please enter a new name ";
          this.setState({
            errors
          });
        }
      }
    }
    if (prevProps.isSaved !== this.props.isSaved) {
      this.setState({
        fields: {
          comments: "",
          name: "",
          username: "",
          password: "",
          aqlGroup: ""
        },
        errors: {},
        showConfirmModal: false
      });
    }
  }

  handleDeleteModal = item =>
    this.setState({
      showDeleteModal: true,
      deletedItem: this.state.deletedItem
    });
  handleAddModal = () => this.setState({ showAddModal: true });
  handleConfirmModal = () => this.setState({ showConfirmModal: true });
  handleCloseModal = () =>
    this.setState({
      showAddModal: false,
      showDeleteModal: false,
      showConfirmModal: false,
      errors: {},
      confirmAction: false
    });
  handleClearForm = type => {
    if (type) {
      this.props.resetAqlGroup(type);
    }
    this.setState({
      fields: {
        comments: "",
        name: "",
        username: "",
        password: "",
        aqlGroup: ""
      },
      errors: {},
      authDetails: null
    });
  };
  handleValidation = param => {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;
    if (param === "add") {
      if (!fields.aqlGroup) {
        formIsValid = false;
        errors.aqlGroup = "Please provide a valid Limit Group name.";
      }
      if (fields.aqlGroup.length >= 50) {
        formIsValid = false;
        errors.aqlGroup = "Max 50 characters allowed.";
      }
      const aqlGroupName =
        this.props.aqlConfigs &&
        this.props.aqlConfigs.find(
          item =>
            item.productName.toLowerCase() === fields.aqlGroup.toLowerCase()
        );
      if (!!aqlGroupName) {
        if (!!this.state.deletedIds.find(x => aqlGroupName.productId === x)) {
          formIsValid = false;
          errors.aqlGroup =
            "Record name existed earlier. Please enter a new name.";
        } else {
          formIsValid = false;
          errors.aqlGroup = "Limit Group already exists.";
        }
      }
    } else {
      if (!fields.comments) {
        formIsValid = false;
        errors.comments = "Comments cannot be empty.";
      }
      if (!fields.name) {
        formIsValid = false;
        errors.name = "Name cannot be empty.";
      }
      if (!fields.username) {
        formIsValid = false;
        errors.username = "Username cannot be empty.";
      }
      if (!fields.password) {
        formIsValid = false;
        errors.password = "Password cannot be empty.";
      }
    }
    this.setState({ errors });
    return formIsValid;
  };
  deleteAqlGroupHandler = id => {
    this.setState({
      deletedIds: [...this.state.deletedIds, id],
      confirmAction: true,
      disabled: false
    });

    const payload = {
      fields: this.state.fields,
      deleteItems: this.state.deletedItem,
    };
    this.setState({deleteData : true});
    this.handleConfirmModal();
    //this.props.deleteLimitGroupData(this.state.deletedItem);
  };
  selectAqlGroupHandler = event => {
    const productId = event.target.value;
    const result = this.props.aqlConfigs.find(u => u.productId == productId);

    this.setState({ deletedItem: result });
  };
  handleChange = (field, e) => {
    let fields = this.state.fields;
    fields[field] = e.target.value;
    if (fields.aqlGroup && fields.aqlGroup.length >= 50) {
      this.handleValidation("add");
    }
    this.setState({ fields });
  };
  checkNamesHandler = () => {
    if (this.handleValidation("add")) {
        this.props.validateLimitGroupNames({aqlGroup: this.state.fields.aqlGroup});
        this.setState({newItems: this.state.fields.aqlGroup});
        this.handleConfirmModal();
    }
  };
  addaqlGroupHandler = () => {
    this.props.addAqlGroup(this.state.fields.aqlGroup);
    this.setState({
      newItems: this.state.fields.aqlGroup,
      fields: {
        aqlGroup: ""
      },
      errors: {},
      confirmAction: true,
      disabled: false
    });
  };
  saveAqlGroupHandler = () => {
    const payload = {
      fields: this.state.fields,
      deleteItems: [],
      newItems: [],
    };

    if (this.state.deleteData) {
      payload.deleteItems.push({productName: this.state.deletedItem.productName})
    } else {
      payload.newItems.push({productName: this.state.newItems})
    }

    this.setState({deleteData : false});
    this.setState({ showConfirmModal: false, confirmAction: true });
    this.props.updateAqlGroupNames(payload);
    // if (this.handleValidation(payload)) {
    //   console.log(payload)
    //   this.props.updateLimitGroupNames(payload);
    // }
  };
  clearHandler = () => {
    if (this.state.newItems.length > 0) {
      this.props.resetAqlGroup(this.state.newItems);
    }
    this.setState({
      selectedIds: [],
      newItems: [],
      deletedIds: [],
      disabled: true
    });
  };
  render() {
    return (
      <>
        <AqlRule
          aqlConfigs={this.props.aqlConfigs}
          deletedIds={this.state.deletedIds}
          clearHandler={this.clearHandler}
          openAdd={this.handleAddModal}
          openDelete={this.handleDeleteModal}
          openConfirm={this.handleConfirmModal}
          changeHandler={this.selectAqlGroupHandler}
          disabled={this.state.disabled}
          isLoading={this.props.isLoading}
          aqlGroupNames={this.props.aqlGroupNames}
          columnDefs={this.state.columnDefs}
          rowData={this.state.rowData}
        />
        <ModalContainer
          showModal={this.state.showDeleteModal}
          handleCloseModal={this.handleCloseModal}
        >
          <DeleteAqlGroup
            handleCloseModal={this.handleCloseModal}
            deleteAqlGroup={this.deleteAqlGroupHandler}
            deletedItem={this.state.deletedItem}
            confirmAction={this.state.confirmAction}
          />
        </ModalContainer>
        <ModalContainer
          showModal={this.state.showAddModal}
          handleCloseModal={this.handleCloseModal}
        >
          <AddAqlGroup
            handleCloseModal={this.handleCloseModal}
            addAqlGroups={this.checkNamesHandler}
            handleClearForm={this.handleClearForm}
            changeHandler={this.handleChange}
            fields={this.state.fields}
            errors={this.state.errors}
            confirmAction={this.state.confirmAction}
            isLoading={this.props.isLoading}
          />
        </ModalContainer>
        <ModalContainer
          showModal={this.state.showConfirmModal}
          handleCloseModal={this.handleCloseModal}
        >
          <UserConfirmation
            handleCloseModal={this.handleCloseModal}
            handleClearForm={this.handleClearForm}
            changeHandler={this.handleChange}
            fields={this.state.fields}
            errors={this.state.errors}
            submitHandler={this.saveLimitGroupHandler}
            authDetails={this.state.authDetails}
            isLoading={this.props.isLoading}
          />
        </ModalContainer>
      </>
    );
  }
}

const mapStateToProps = state => {
  return {
    aqlConfigs: state.aqlConfigs.aqlGroupData,
    isLoading: state.aqlConfigs.isLoading,
    AqlGroupNames: state.aqlConfigs.aqlGroupNames,
    authDetails: state.aqlConfigs.authDetails,
    isSaved: state.aqlConfigs.isSaved
  };
};

const mapDispatchToProps = dispatch => ({
  fetchAqlConfigs: () => dispatch(actions.fetchAqlConfigs()),
  updateAqlGroupNames: payload =>
    dispatch(actions.updateAqlGroupNames(payload)),
  deleteProductData: payload => dispatch(actions.deleteProductData(payload)),
  addAqlGroups: payload => dispatch(actions.addAqlGroups(payload)),
  deleteAqlGroupData: payload =>
    dispatch(actions.deleteAqlGroupData(payload)),
  validateAqlGroupNames: payload =>
    dispatch(actions.checkLimitGroupNames(payload)),
  resetAqlGroup: payload => dispatch(actions.resetAqlGroup(payload))
});

export default connect(mapStateToProps, mapDispatchToPrps)(AqlGroups);
