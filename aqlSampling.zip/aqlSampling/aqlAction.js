import * as actionTypes from "./actionTypes";

export const fetchAqlConfigs = () => ({
  type: actionTypes.FETCH_AQL_GROUP_REQUESTED
});

export const updateAqlGroupNames = (req) => ({
  type: actionTypes.UPDATE_AQL_GROUP_REQUESTED,
  payload: req
});

export const checkAqlGroupNames = (req) => ({
  type: actionTypes.VALIDATE_AQL_GROUP_NAMES_REQUESTED,
  payload: req
});

export const addAqlGroup = (req) => ({
  type: actionTypes.ADD_AQL_GROUP,
  payload: req
});

export const addDefectRulesData = (req) => ({
  type: actionTypes.ADD_AQL_DEFECT_GROUP,
  payload: req
});

export const deleteAqlGroupData = (req) => ({
  type: actionTypes.DELETE_AQL_GROUP_DATA,
  payload: req
});

export const deleteProductData = (req) => ({
  type: actionTypes.DELETE_AQLGROUP_DATA,
  payload: req
});

export const resetAqlGroup = (req) => ({
  type: actionTypes.FETCH_AQL_GROUP_RESET,
  payload: req
});

export const getDefectAqlRules = (req) => ({
  type: actionTypes.FETCH_DEFECT_AQL_GROUP_RULE_REQUESTED,
  payload: req
});